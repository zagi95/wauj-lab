package hr.tvz.zagar.studapp.command;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Negative;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public class FakultetCommand {

    @NotBlank
    private String name;
    @NotBlank
    private String address;
    @NotNull
    @Negative
    private Integer numOfStudents;
    @NotBlank
    private String dekan;
    @NotBlank
    private String oib;
    @NotNull
    @JsonFormat(pattern = "dd.MM.yyyy.")
    @Future
    private LocalDate datumOsnivanja;

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Integer getNumOfStudents() {
        return numOfStudents;
    }

    public String getDekan() {
        return dekan;
    }

    public String getOib() {
        return oib;
    }

    public LocalDate getDatumOsnivanja() {
        return datumOsnivanja;
    }
}
