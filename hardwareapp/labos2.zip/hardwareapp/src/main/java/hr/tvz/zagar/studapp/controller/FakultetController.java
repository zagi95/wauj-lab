package hr.tvz.zagar.studapp.controller;

import hr.tvz.zagar.studapp.command.FakultetCommand;
import hr.tvz.zagar.studapp.command.StudentCommand;
import hr.tvz.zagar.studapp.dto.FakultetDTO;
import hr.tvz.zagar.studapp.dto.StudentDTO;
import hr.tvz.zagar.studapp.service.FakultetService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("fakultet")
public class FakultetController {

    private final FakultetService fakultetService;

    public FakultetController(FakultetService fakultetService) {
        this.fakultetService = fakultetService;
    }

    @GetMapping()
    public List<FakultetDTO> getAllFaks(){
        return fakultetService.findAll();
    }

    @GetMapping(params = "oib")
    public ResponseEntity<FakultetDTO> getFakultetByOib(@RequestParam final String oib){
        return fakultetService.findFakultetByOib(oib)
                .map(
                        fakultetDTO -> ResponseEntity
                                .status(HttpStatus.CREATED)
                                .body(fakultetDTO)
                ).orElseGet(
                        () -> ResponseEntity
                                .status(HttpStatus.NO_CONTENT)
                                .build()
                );
    }
    @PostMapping
    public ResponseEntity<FakultetDTO> save(@Valid @RequestBody final FakultetCommand command){
        return fakultetService.save(command)
                .map(
                        studentDto -> ResponseEntity
                                .status(HttpStatus.CREATED)
                                .body(studentDto)
                )
                .orElseGet(
                        () -> ResponseEntity
                                .status(HttpStatus.CONFLICT)
                                .build()
                );
    }
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("/{oib}")
    public void deleteByOib(@PathVariable String oib){
        fakultetService.deleteByOib(oib);
    }
}
