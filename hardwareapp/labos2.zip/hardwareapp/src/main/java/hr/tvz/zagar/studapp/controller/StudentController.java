package hr.tvz.zagar.studapp.controller;

import hr.tvz.zagar.studapp.command.StudentCommand;
import hr.tvz.zagar.studapp.dto.StudentDTO;
import hr.tvz.zagar.studapp.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("student")
public class StudentController {
    private final StudentService studentService;
    public StudentController(StudentService studentService){
        this.studentService = studentService;
    }

    @GetMapping()
    public List<StudentDTO> getAllStudents(){
        return studentService.findAll();
    }

    @GetMapping(params = "JMBAG")
    public ResponseEntity<StudentDTO> getStudentByJMBAG(@RequestParam final String JMBAG){
        return studentService.findStudentByJMBAG(JMBAG)
                .map(
                        studentDTO -> ResponseEntity
                                .status(HttpStatus.CREATED)
                                .body(studentDTO)
                ).orElseGet(
                        () -> ResponseEntity
                                .status(HttpStatus.NO_CONTENT)
                                .build()
                );
    }
    @PostMapping
    public ResponseEntity<StudentDTO> save(@Valid @RequestBody final StudentCommand command){
        return studentService.save(command)
                .map(
                        studentDto -> ResponseEntity
                                .status(HttpStatus.CREATED)
                                .body(studentDto)
                )
                .orElseGet(
                        () -> ResponseEntity
                                .status(HttpStatus.CONFLICT)
                                .build()
                );
    }
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("/{JMBAG}")
    public void deleteByJMBAG(@PathVariable String JMBAG){
        studentService.deleteByJmbag(JMBAG);
    }
}
