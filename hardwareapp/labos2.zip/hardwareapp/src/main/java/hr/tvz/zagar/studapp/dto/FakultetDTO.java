package hr.tvz.zagar.studapp.dto;

public class FakultetDTO {
    private String OIB;
    private Integer numOfStudents;
    private String address;

    public FakultetDTO(String OIB, Integer numOfStudents, String address) {
        this.OIB = OIB;
        this.numOfStudents = numOfStudents;
        this.address = address;
    }

    public String getOIB() {
        return OIB;
    }

    public Integer getNumOfStudents() {
        return numOfStudents;
    }

    public String getAddress() {
        return address;
    }

    public void setOIB(String OIB) {
        this.OIB = OIB;
    }

    public void setNumOfStudents(Integer numOfStudents) {
        this.numOfStudents = numOfStudents;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
