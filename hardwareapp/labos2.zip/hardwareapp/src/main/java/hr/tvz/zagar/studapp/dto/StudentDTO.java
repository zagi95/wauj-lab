package hr.tvz.zagar.studapp.dto;

public class StudentDTO {
    private String jmbag;
    private Integer ects;
    private final boolean needsToPay;

    public StudentDTO(String jmbag, Integer ects, boolean needsToPay) {
        this.jmbag = jmbag;
        this.ects = ects;
        this.needsToPay = needsToPay;
    }

    public String getJmbag() {
        return jmbag;
    }

    public Integer getEcts() {
        return ects;
    }

    public boolean isNeedsToPay() {
        return needsToPay;
    }

    public void setJmbag(String jmbag) {
        this.jmbag = jmbag;
    }

    public void setEcts(Integer ects) {
        this.ects = ects;
    }
    @Override
    public String toString() {
        return "StudentDTO{" +
                "JMBAG='" + jmbag + '\'' +
                ", numberOfECTS=" + ects +
                ", tuitionShouldBePaid=" + needsToPay +
                '}';
    }

}
