package hr.tvz.zagar.studapp.entity;

import java.time.LocalDate;

public class Fakultet {
    private String name;
    private String address;
    private Integer numOfStudents;
    private String dekan;
    private String OIB;
    private LocalDate datumOsnivanja;

    public Fakultet(String name, String address, Integer numOfStudents, String dekan, String OIB, LocalDate datumOsnivanja) {
        this.name = name;
        this.address = address;
        this.numOfStudents = numOfStudents;
        this.dekan = dekan;
        this.OIB = OIB;
        this.datumOsnivanja = datumOsnivanja;
    }


    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getNumOfStudents() {
        return numOfStudents;
    }

    public String getDekan() {
        return dekan;
    }

    public String getOIB() {
        return OIB;
    }

    public void setNumOfStudents(Integer numOfStudents) {
        this.numOfStudents = numOfStudents;
    }

    public void setDekan(String dekan) {
        this.dekan = dekan;
    }

    public void setOIB(String OIB) {
        this.OIB = OIB;
    }
}
