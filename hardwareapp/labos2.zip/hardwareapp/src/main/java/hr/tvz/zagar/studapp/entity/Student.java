package hr.tvz.zagar.studapp.entity;

import java.time.LocalDate;

public class Student {
    private final String firstName;
    private final String lastName;
    private final LocalDate dateOfBirth;
    private final String jmbag;
    private Integer ects;

    public Student(String firstName, String lastName, LocalDate dateOfBirth, String jmbag, Integer ects) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.jmbag = jmbag;
        this.ects = ects;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public String getJmbag() {
        return jmbag;
    }

    public Integer getEcts() {
        return ects;
    }

    public boolean needsToPay(){
        return dateOfBirth.isAfter(LocalDate.now().minusYears(26));
    }
}
