package hr.tvz.zagar.studapp.repository;

import hr.tvz.zagar.studapp.command.FakultetCommand;
import hr.tvz.zagar.studapp.command.StudentCommand;
import hr.tvz.zagar.studapp.entity.Fakultet;
import hr.tvz.zagar.studapp.entity.Student;

import java.nio.channels.FileChannel;
import java.util.List;
import java.util.Optional;

public interface FakultetRepository {
    List<Fakultet> findAll();
    Optional<Fakultet> findFakultetByOIB(String oib);
    Optional<Fakultet> save(FakultetCommand command);
}
