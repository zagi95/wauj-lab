package hr.tvz.zagar.studapp.repository;

import hr.tvz.zagar.studapp.command.FakultetCommand;
import hr.tvz.zagar.studapp.entity.Fakultet;
import hr.tvz.zagar.studapp.entity.Student;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.*;

@Repository
public class FakultetRepositoryImpl implements FakultetRepository{

    List<Fakultet> fakultetList = new ArrayList<>(Arrays.asList(
            new Fakultet("ime1", "adresa1", 1, "dekan1", "oib1", LocalDate.of(1900, 11,11)),
            new Fakultet("ime2", "adresa2", 2, "dekan2", "oib2", LocalDate.of(1800, 11,11))
    )
    );

    @Override
    public List<Fakultet> findAll() {
        return fakultetList;
    }

    @Override
    public Optional<Fakultet> findFakultetByOIB(String oib) {
        return fakultetList.stream()
                .filter(fakultet -> Objects.equals(fakultet.getOIB(), oib))
                .findAny();
    }

    @Override
    public Optional<Fakultet> save(FakultetCommand command) {
        Fakultet fakultet = new Fakultet(
                command.getName(),
                command.getAddress(),
                command.getNumOfStudents(),
                command.getDekan(),
                command.getOib(),
                command.getDatumOsnivanja());
        fakultetList.add(fakultet);

        return Optional.of(fakultet);
    }
}
