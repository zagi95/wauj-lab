package hr.tvz.zagar.studapp.repository;

import hr.tvz.zagar.studapp.command.StudentCommand;
import hr.tvz.zagar.studapp.entity.Student;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.*;

@Repository
public class StudentRepositoryImpl implements StudentRepository {
    List<Student> studentList = new ArrayList<>(Arrays.asList(
            new Student("mate", "miso", LocalDate.of(2000, 2, 22), "1234567890", 150),
            new Student("stipe", "stipic", LocalDate.of(1999, 1, 11), "654321", 155)
    )
    );
    @Override
    public List<Student> findAll() {
        return studentList;
    }
    @Override
    public Optional<Student> findStudentByJMBAG(String JMBAG) {
        return studentList.stream()
                .filter(student -> Objects.equals(student.getJmbag(), JMBAG))
                .findAny();
    }

    @Override
    public Optional<Student> save(StudentCommand command) {
        Student student = new Student(
                command.getFirstName(),
                command.getLastName(),
                command.getDateOfBirth(),
                command.getJmbag(),
                command.getNumberOfECTS());
        studentList.add(student);

        return Optional.of(student);
    }
}
