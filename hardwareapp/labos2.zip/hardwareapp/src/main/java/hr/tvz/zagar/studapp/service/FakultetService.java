package hr.tvz.zagar.studapp.service;

import hr.tvz.zagar.studapp.command.FakultetCommand;
import hr.tvz.zagar.studapp.dto.FakultetDTO;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

public interface FakultetService {
    List<FakultetDTO> findAll();
    Optional<FakultetDTO> findFakultetByOib(String oib);

    Optional<FakultetDTO> save(@Valid FakultetCommand command);

    void deleteByOib(String oib);
}
