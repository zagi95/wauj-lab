package hr.tvz.zagar.studapp.service;

import hr.tvz.zagar.studapp.command.FakultetCommand;
import hr.tvz.zagar.studapp.dto.FakultetDTO;
import hr.tvz.zagar.studapp.dto.StudentDTO;
import hr.tvz.zagar.studapp.entity.Fakultet;
import hr.tvz.zagar.studapp.entity.Student;
import hr.tvz.zagar.studapp.repository.FakultetRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FakultetServiceImpl implements FakultetService{

    private final FakultetRepository fakultetRepository;

    public FakultetServiceImpl(FakultetRepository fakultetRepository) {
        this.fakultetRepository = fakultetRepository;
    }

    @Override
    public List<FakultetDTO> findAll() {
        return fakultetRepository.findAll().stream()
                .map(fakultet -> new FakultetDTO(fakultet.getOIB(), fakultet.getNumOfStudents(), fakultet.getAddress()))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<FakultetDTO> findFakultetByOib(String oib) {
        return fakultetRepository.findFakultetByOIB(oib).stream()
                .map(fakultet -> new FakultetDTO(fakultet.getOIB(), fakultet.getNumOfStudents(),fakultet.getAddress()))
                .findAny();
    }

    @Override
    public Optional<FakultetDTO> save(FakultetCommand command) {
        if(fakultetRepository.findFakultetByOIB(command.getOib()).isPresent()){
            return Optional.ofNullable(null);
        }
        else {
            return fakultetRepository.save(command)
                    .map(fakultet -> new FakultetDTO(fakultet.getOIB(), fakultet.getNumOfStudents(), fakultet.getAddress()));
        }
    }

    @Override
    public void deleteByOib(String oib) {
        Fakultet student = fakultetRepository.findFakultetByOIB(oib).get();
        fakultetRepository.findAll().remove(student);
    }
}
