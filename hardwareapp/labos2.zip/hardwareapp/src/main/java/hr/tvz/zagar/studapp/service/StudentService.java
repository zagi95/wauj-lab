package hr.tvz.zagar.studapp.service;

import hr.tvz.zagar.studapp.command.StudentCommand;
import hr.tvz.zagar.studapp.dto.StudentDTO;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface StudentService {

    List<StudentDTO> findAll();
    Optional<StudentDTO> findStudentByJMBAG(String JMBAG);

    Optional<StudentDTO> save(@Valid StudentCommand command);

    void deleteByJmbag(String JMBAG);
}
