package hr.tvz.zagar.studapp.service;

import hr.tvz.zagar.studapp.command.StudentCommand;
import hr.tvz.zagar.studapp.dto.StudentDTO;
import hr.tvz.zagar.studapp.entity.Student;
import hr.tvz.zagar.studapp.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository repository){
        this.studentRepository = repository;
    }
    @Override
    public List<StudentDTO> findAll() {
        return studentRepository.findAll().stream()
                .map(student -> new StudentDTO(student.getJmbag(), student.getEcts(), student.needsToPay()))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<StudentDTO> findStudentByJMBAG(String JMBAG) {
        return studentRepository.findStudentByJMBAG(JMBAG).stream()
                .map(student -> new StudentDTO(student.getJmbag(), student.getEcts(), student.needsToPay()))
                .findAny();
    }

    @Override
    public Optional<StudentDTO> save(StudentCommand command) {
        if(studentRepository.findStudentByJMBAG(command.getJmbag()).isPresent()){
            return Optional.ofNullable(null);
        }
        else {
            return studentRepository.save(command)
                    .map(student -> new StudentDTO(student.getJmbag(), student.getEcts(), student.needsToPay()));
        }

    }

    @Override
    public void deleteByJmbag(String JMBAG) {
        Student student = studentRepository.findStudentByJMBAG(JMBAG).get();
        studentRepository.findAll().remove(student);
    }
}
